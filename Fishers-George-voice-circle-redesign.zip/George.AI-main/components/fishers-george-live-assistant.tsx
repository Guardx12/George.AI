"use client"

import { useEffect, useMemo, useRef, useState } from "react"
import {
  ArrowLeft,
  BedDouble,
  CalendarDays,
  ChevronDown,
  Loader2,
  MapPinned,
  Mic,
  PhoneOff,
  Radio,
  Sparkles,
  Ticket,
  Trees,
  UtensilsCrossed,
  BadgeHelp,
  PawPrint,
  Volume2,
  RotateCcw,
} from "lucide-react"

type LiveMessage = {
  id: string
  role: "assistant" | "user" | "system"
  content: string
}

type ConnectionState = "idle" | "connecting" | "connected" | "error"

const STORAGE_KEY = "fishers-george-session-v1"

const INITIAL_MESSAGES: LiveMessage[] = [
  {
    id: "intro",
    role: "system",
    content:
      "Hello — I’m George, your guide for Fishers Farm Park. I can help whether you’re planning your visit or already here, from tickets and what to expect to directions, animals, food, interesting facts, and what to do next.",
  },
]

const QUICK_LINKS = [
  { label: "Buy Tickets", href: "https://fishersfarmpark.visihost.co.uk/", icon: Ticket },
  { label: "Annual Pass", href: "https://www.fishersfarmpark.co.uk/annual-pass", icon: Ticket },
  { label: "Plan Your Visit", href: "https://www.fishersfarmpark.co.uk/plan-your-visit", icon: MapPinned },
  { label: "What’s On", href: "https://www.fishersfarmpark.co.uk/events", icon: CalendarDays },
  { label: "Attractions", href: "https://www.fishersfarmpark.co.uk/attractions", icon: Sparkles },
  { label: "Animals", href: "https://www.fishersfarmpark.co.uk/animals", icon: PawPrint },
  { label: "Food & Drink", href: "https://www.fishersfarmpark.co.uk/food", icon: UtensilsCrossed },
  { label: "Holiday Cottages", href: "https://www.fishersfarmpark.co.uk/holiday-cottages", icon: BedDouble },
  { label: "Luxury Pods", href: "https://www.fishersfarmpark.co.uk/holiday-pods", icon: Trees },
  { label: "FAQs", href: "https://www.fishersfarmpark.co.uk/faq", icon: BadgeHelp },
  { label: "Back to Fishers Farm Park", href: "https://www.fishersfarmpark.co.uk/", icon: ArrowLeft },
]

type StoredSession = {
  messages: LiveMessage[]
  visitorName: string | null
  updatedAt: number
}

function makeMessage(role: LiveMessage["role"], content: string) {
  return {
    id:
      typeof crypto !== "undefined" && "randomUUID" in crypto
        ? crypto.randomUUID()
        : `${role}-${Date.now()}-${Math.random()}`,
    role,
    content,
  }
}

function trimMessagesForStorage(messages: LiveMessage[]) {
  return messages.slice(-24)
}

function detectVisitorName(messages: LiveMessage[]) {
  for (let i = 1; i < messages.length; i += 1) {
    const prev = messages[i - 1]
    const current = messages[i]
    if (prev.role === "assistant" && /what['’]s your name|what is your name/i.test(prev.content) && current.role === "user") {
      const cleaned = current.content
        .replace(/^(it'?s|its|i am|i'm|im|my name is|name'?s|this is|es)\s+/i, "")
        .replace(/[^A-Za-z' -]/g, " ")
        .trim()
      const first = cleaned.split(/\s+/).find(Boolean)
      if (first && first.length >= 2) {
        return first.charAt(0).toUpperCase() + first.slice(1).toLowerCase()
      }
    }
  }
  return null
}

function buildFirstResponseEvent(visitorName: string | null, hasStoredSession: boolean, lastUserMessage: string | null) {
  const instructions = hasStoredSession
    ? `Introduce yourself as George for Fishers Farm Park in warm, natural British English only. Keep it short, cheerful, and family-friendly. This visitor already has an ongoing conversation with you on this device. Do not restart from scratch and do not ask again whether they are planning their visit or already here unless you truly need to. ${visitorName ? `Their name is ${visitorName}. Use it lightly and warmly.` : ""} ${lastUserMessage ? `The last thing they said before returning was: ${lastUserMessage}` : ""} Briefly welcome them back, pick up naturally, and ask one short forward-moving question such as what they can see now, where they are now, or what they want help with next.`
    : "Introduce yourself as George for Fishers Farm Park in warm, natural British English only. Keep it short, cheerful, and family-friendly. Briefly say you can help whether someone is planning their visit or already at the park. Then ask this exact question naturally: Are you planning your visit, or are you already here at Fishers Farm? Once they reply, ask for their name naturally early in the conversation if they have not already given it. Do not ask lots of questions at once. Never ask whether they are a child or an adult. If they mention family or children, ask about that naturally afterwards. If they are planning, guide them towards the most relevant buttons on the page. If they are already here, guide them around the park, suggest what to do next, offer interesting animal facts when relevant, and mention food or drink naturally where it fits. Use names lightly and warmly, not in every reply."

  return {
    type: "response.create",
    response: { instructions },
  }
}

export function FishersGeorgeLiveAssistant() {
  const [messages, setMessages] = useState<LiveMessage[]>(INITIAL_MESSAGES)
  const [connectionState, setConnectionState] = useState<ConnectionState>("idle")
  const [statusText, setStatusText] = useState("Ready when you are")
  const [isModelSpeaking, setIsModelSpeaking] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [hasStoredSession, setHasStoredSession] = useState(false)
  const [visitorName, setVisitorName] = useState<string | null>(null)

  const pcRef = useRef<RTCPeerConnection | null>(null)
  const dcRef = useRef<RTCDataChannel | null>(null)
  const audioRef = useRef<HTMLAudioElement | null>(null)
  const localStreamRef = useRef<MediaStream | null>(null)
  const currentAssistantTextRef = useRef("")
  const currentAssistantMessageIdRef = useRef<string | null>(null)
  const scrollRef = useRef<HTMLDivElement | null>(null)

  const canStart = useMemo(() => connectionState === "idle" || connectionState === "error", [connectionState])

  const lastAssistantMessage = useMemo(() => {
    return [...messages].reverse().find((message) => message.role === "assistant")?.content ?? INITIAL_MESSAGES[0].content
  }, [messages])

  const visibleMessages = useMemo(() => messages.filter((message) => message.role !== "system"), [messages])

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight
    }
  }, [messages, connectionState])

  useEffect(() => {
    try {
      const raw = window.localStorage.getItem(STORAGE_KEY)
      if (!raw) return
      const stored = JSON.parse(raw) as StoredSession
      if (Array.isArray(stored?.messages) && stored.messages.length > 1) {
        setMessages(stored.messages)
        setHasStoredSession(true)
        setVisitorName(stored.visitorName || detectVisitorName(stored.messages))
        setStatusText("Ready to carry on")
      }
    } catch {}
  }, [])

  useEffect(() => {
    try {
      const trimmed = trimMessagesForStorage(messages)
      const detectedName = visitorName || detectVisitorName(trimmed)
      if (detectedName && detectedName !== visitorName) setVisitorName(detectedName)
      if (trimmed.length <= 1) {
        window.localStorage.removeItem(STORAGE_KEY)
        setHasStoredSession(false)
        return
      }
      const payload: StoredSession = {
        messages: trimmed,
        visitorName: detectedName,
        updatedAt: Date.now(),
      }
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(payload))
      setHasStoredSession(true)
    } catch {}
  }, [messages, visitorName])

  async function cleanupConversation() {
    dcRef.current?.close()
    dcRef.current = null

    if (pcRef.current) {
      pcRef.current.getSenders().forEach((sender) => sender.track?.stop())
      pcRef.current.close()
      pcRef.current = null
    }

    if (localStreamRef.current) {
      localStreamRef.current.getTracks().forEach((track) => track.stop())
      localStreamRef.current = null
    }

    if (audioRef.current) {
      audioRef.current.pause()
      audioRef.current.srcObject = null
      audioRef.current.remove()
      audioRef.current = null
    }

    currentAssistantTextRef.current = ""
    currentAssistantMessageIdRef.current = null
    setIsModelSpeaking(false)
  }

  function clearSavedSession() {
    void cleanupConversation()
    setMessages(INITIAL_MESSAGES)
    setVisitorName(null)
    setHasStoredSession(false)
    setError(null)
    setConnectionState("idle")
    setStatusText("Ready when you are")
    try {
      window.localStorage.removeItem(STORAGE_KEY)
    } catch {}
  }

  function appendOrUpdateAssistantPartial(delta: string, isFinal = false) {
    if (!delta) return

    if (!currentAssistantMessageIdRef.current) {
      const message = makeMessage("assistant", delta)
      currentAssistantMessageIdRef.current = message.id
      currentAssistantTextRef.current = delta
      setMessages((prev) => [...prev, message])
      if (isFinal) {
        currentAssistantMessageIdRef.current = null
        currentAssistantTextRef.current = ""
      }
      return
    }

    currentAssistantTextRef.current += delta
    const targetId = currentAssistantMessageIdRef.current
    setMessages((prev) => prev.map((message) => (message.id === targetId ? { ...message, content: currentAssistantTextRef.current } : message)))

    if (isFinal) {
      currentAssistantMessageIdRef.current = null
      currentAssistantTextRef.current = ""
    }
  }

  function addUserTranscript(text: string) {
    const cleaned = text.trim()
    if (!cleaned) return
    setMessages((prev) => [...prev, makeMessage("user", cleaned)])
  }

  function handleRealtimeEvent(event: any) {
    const type = event?.type
    if (!type) return

    switch (type) {
      case "session.created":
      case "session.updated":
        setStatusText("Live conversation on")
        break
      case "input_audio_buffer.speech_started":
        setStatusText("Listening…")
        break
      case "input_audio_buffer.speech_stopped":
        setStatusText("Thinking…")
        break
      case "response.created":
      case "response.output_audio.delta":
        setIsModelSpeaking(true)
        setStatusText("George is replying…")
        break
      case "response.output_audio.done":
        setIsModelSpeaking(false)
        setStatusText("Listening…")
        break
      case "response.output_audio_transcript.delta":
        appendOrUpdateAssistantPartial(typeof event.delta === "string" ? event.delta : "")
        break
      case "response.output_audio_transcript.done":
        appendOrUpdateAssistantPartial(typeof event.transcript === "string" ? event.transcript : "", true)
        break
      case "conversation.item.input_audio_transcription.completed":
        addUserTranscript(typeof event.transcript === "string" ? event.transcript : "")
        break
      case "response.output_item.done": {
        const content = Array.isArray(event?.item?.content) ? event.item.content : []
        const transcript = content
          .map((part: any) => {
            if (typeof part?.transcript === "string") return part.transcript
            if (typeof part?.text === "string") return part.text
            return ""
          })
          .filter(Boolean)
          .join("\n")
        if (transcript) appendOrUpdateAssistantPartial(transcript, true)
        break
      }
      case "error": {
        const message = event?.error?.message || "George hit a voice error."
        if (connectionState === "connected") {
          setError(message)
          setStatusText("There was a connection problem")
        } else {
          void cleanupConversation()
          setConnectionState("error")
          setStatusText("Could not connect George")
          setError(message)
        }
        break
      }
      default:
        break
    }
  }

  async function startConversation() {
    if (!canStart) return

    await cleanupConversation()
    setConnectionState("connecting")
    setError(null)
    setStatusText("Connecting George…")
    setMessages((prev) => (hasStoredSession && prev.length > 1 ? prev : INITIAL_MESSAGES))

    try {
      const tokenResponse = await fetch("/api/fishers-session", {
        method: "GET",
        cache: "no-store",
      })

      const tokenData = await tokenResponse.json().catch(() => null)
      if (!tokenResponse.ok) {
        throw new Error(
          typeof tokenData?.error === "string" ? tokenData.error : "Could not create a secure live session.",
        )
      }

      const ephemeralKey = tokenData?.value
      if (typeof ephemeralKey !== "string" || !ephemeralKey) {
        throw new Error("Live voice token was missing.")
      }

      const pc = new RTCPeerConnection()
      pcRef.current = pc

      const remoteAudio = document.createElement("audio")
      remoteAudio.autoplay = true
      remoteAudio.playsInline = true
      audioRef.current = remoteAudio

      pc.ontrack = (event) => {
        const [remoteStream] = event.streams
        if (remoteStream) {
          remoteAudio.srcObject = remoteStream
          void remoteAudio.play().catch(() => {})
        }
      }

      const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
      localStreamRef.current = stream
      stream.getTracks().forEach((track) => pc.addTrack(track, stream))

      const dataChannel = pc.createDataChannel("oai-events")
      dcRef.current = dataChannel

      dataChannel.addEventListener("open", () => {
        setConnectionState("connected")
        setStatusText("Live conversation on")
        const lastUserMessage = [...messages].reverse().find((message) => message.role === "user")?.content ?? null
        const event = buildFirstResponseEvent(visitorName, hasStoredSession && messages.length > 1, lastUserMessage)
        window.setTimeout(() => {
          dataChannel.send(JSON.stringify(event))
        }, 150)
      })

      dataChannel.addEventListener("message", (event) => {
        try {
          handleRealtimeEvent(JSON.parse(event.data))
        } catch {}
      })

      const offer = await pc.createOffer()
      await pc.setLocalDescription(offer)

      const sdpResponse = await fetch("https://api.openai.com/v1/realtime/calls", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${ephemeralKey}`,
          "Content-Type": "application/sdp",
        },
        body: offer.sdp,
      })

      const answer = await sdpResponse.text()

      if (!sdpResponse.ok) {
        let message = "Could not connect George."

        try {
          const parsed = JSON.parse(answer)
          if (typeof parsed?.error?.message === "string") {
            message = parsed.error.message
          }
        } catch {
          if (answer.includes("<html") || answer.includes("<!DOCTYPE html")) {
            message = "The live voice service timed out while connecting. Please try again."
          } else if (answer.trim()) {
            message = answer.trim()
          }
        }

        throw new Error(message)
      }

      await pc.setRemoteDescription({ type: "answer", sdp: answer })

      pc.addEventListener("connectionstatechange", () => {
        if (pc.connectionState === "failed" || pc.connectionState === "disconnected" || pc.connectionState === "closed") {
          setConnectionState("error")
          setStatusText("Connection ended")
        }
      })
    } catch (err) {
      await cleanupConversation()
      setConnectionState("error")
      setStatusText("Could not connect George")
      setError(err instanceof Error ? err.message : "Could not connect George right now.")
    }
  }

  async function stopConversation() {
    await cleanupConversation()
    setError(null)
    setConnectionState("idle")
    setStatusText(hasStoredSession ? "Ready to carry on" : "Ready when you are")
  }

  const circleClasses =
    connectionState === "connected"
      ? "scale-100 shadow-[0_34px_90px_rgba(15,59,130,0.35)]"
      : connectionState === "connecting"
        ? "scale-[1.02] shadow-[0_30px_80px_rgba(15,59,130,0.28)]"
        : "scale-100 shadow-[0_26px_70px_rgba(15,59,130,0.18)] hover:scale-[1.01]"

  return (
    <section className="mx-auto w-full max-w-7xl px-4 py-8 sm:px-6 lg:px-8 lg:py-10">
      <div className="overflow-hidden rounded-[40px] border border-[#d9e4f4] bg-white shadow-[0_30px_100px_rgba(15,59,130,0.10)]">
        <div className="relative overflow-hidden border-b border-[#e4edf8] bg-white px-5 py-10 text-center sm:px-8 sm:py-14">
          <div className="absolute inset-x-0 top-0 h-40 bg-[radial-gradient(circle_at_top,_rgba(72,126,214,0.16),_transparent_68%)]" />
          <img src="/fishers-logo.svg" alt="Fishers Farm Adventure Park" className="relative mx-auto h-auto w-full max-w-[320px]" />
          <p className="relative mt-8 text-sm font-semibold uppercase tracking-[0.3em] text-[#3c67b7]">Meet George</p>
          <h1 className="relative mt-3 text-4xl font-black tracking-tight text-[#0f2f63] sm:text-6xl">
            Your 24/7 voice guide for Fishers Farm Park
          </h1>
          <p className="relative mx-auto mt-5 max-w-3xl text-base leading-7 text-[#45608f] sm:text-lg">
            Tap the circle and speak to George. He helps before you arrive and while you’re in the park — from tickets,
            animals, and planning your day to directions, food, and what to do next.
          </p>
          <div className="relative mx-auto mt-6 inline-flex items-center gap-2 rounded-full border border-[#dbe7f6] bg-[#f7fbff] px-4 py-2 text-sm font-medium text-[#33538b] shadow-sm">
            {connectionState === "connected" ? <Volume2 className="h-4 w-4" /> : <Radio className="h-4 w-4" />}
            <span>{isModelSpeaking ? "George is talking" : statusText}</span>
          </div>
        </div>

        <div className="grid gap-0 lg:grid-cols-[1.2fr_0.8fr]">
          <div className="border-b border-[#e4edf8] bg-white px-5 py-8 sm:px-8 sm:py-10 lg:border-b-0 lg:border-r">
            <div className="mx-auto flex max-w-4xl flex-col items-center text-center">
              <div className="relative flex h-[320px] w-full items-center justify-center sm:h-[380px]">
                <div className="absolute h-72 w-72 rounded-full bg-[radial-gradient(circle,_rgba(82,139,231,0.18),_transparent_68%)] blur-2xl" />
                {(connectionState === "connected" || connectionState === "connecting") && (
                  <>
                    <div className="absolute h-[250px] w-[250px] animate-ping rounded-full border border-[#4d77c3]/25" />
                    <div className="absolute h-[290px] w-[290px] animate-pulse rounded-full border border-[#7aa0df]/20" />
                  </>
                )}

                <button
                  type="button"
                  onClick={connectionState === "connected" ? stopConversation : startConversation}
                  disabled={connectionState === "connecting"}
                  aria-label={connectionState === "connected" ? "Stop talking to George" : "Start talking to George"}
                  className={`group relative flex h-56 w-56 items-center justify-center overflow-hidden rounded-full border border-[#1d4f9f]/10 bg-[linear-gradient(145deg,#0a2857_0%,#123d82_58%,#3f70c7_100%)] text-white transition duration-300 ${circleClasses} disabled:cursor-wait disabled:opacity-95 sm:h-64 sm:w-64`}
                >
                  <span className="absolute inset-0 bg-[linear-gradient(120deg,transparent_20%,rgba(255,255,255,0.28)_50%,transparent_80%)] translate-x-[-120%] animate-[shine_3.5s_linear_infinite]" />
                  <span className="absolute inset-[10px] rounded-full border border-white/12" />
                  <span className={`absolute inset-[24px] rounded-full ${connectionState === "connected" ? "bg-white/10" : "bg-white/6"}`} />
                  <span className="relative z-10 flex flex-col items-center gap-3 px-5 text-center">
                    {connectionState === "connecting" ? (
                      <Loader2 className="h-10 w-10 animate-spin" />
                    ) : connectionState === "connected" ? (
                      <PhoneOff className="h-10 w-10" />
                    ) : (
                      <Mic className="h-10 w-10 transition group-hover:scale-110" />
                    )}
                    <span className="text-2xl font-black tracking-tight sm:text-[30px]">George</span>
                    <span className="text-sm font-medium text-white/88 sm:text-base">
                      {connectionState === "connected"
                        ? "Tap to end"
                        : connectionState === "connecting"
                          ? "Connecting…"
                          : hasStoredSession
                            ? `Tap to carry on${visitorName ? `, ${visitorName}` : ""}`
                            : "Tap to speak"}
                    </span>
                  </span>
                </button>
              </div>

              <div className="min-h-[104px] max-w-3xl px-2">
                <div className="mx-auto max-w-2xl rounded-[28px] border border-[#dde7f5] bg-[#f7fbff] px-6 py-5 shadow-[0_14px_40px_rgba(15,59,130,0.06)]">
                  <p className="text-xs font-semibold uppercase tracking-[0.24em] text-[#4f77c4]">
                    {connectionState === "connected"
                      ? isModelSpeaking
                        ? "George is saying"
                        : "Conversation live"
                      : hasStoredSession
                        ? "Ready to carry on"
                        : "How it works"}
                  </p>
                  <p
                    key={lastAssistantMessage}
                    className="mt-3 text-lg font-medium leading-8 text-[#163867] motion-safe:animate-[captionFade_4.2s_ease-in-out]"
                  >
                    {connectionState === "connected"
                      ? lastAssistantMessage
                      : hasStoredSession
                        ? `George remembers the flow on this device${visitorName ? `, ${visitorName}` : ""}. Tap the circle and carry on naturally.`
                        : "Tap the circle once and George starts straight away. Speak naturally, listen to the reply, and watch the caption appear underneath."}
                  </p>
                </div>
              </div>

              <div className="mt-6 flex flex-wrap items-center justify-center gap-3">
                {hasStoredSession && connectionState !== "connected" ? (
                  <button
                    type="button"
                    onClick={clearSavedSession}
                    className="inline-flex items-center justify-center gap-2 rounded-full border border-[#d8e4f4] bg-white px-5 py-3 text-sm font-semibold text-[#385889] transition hover:bg-[#f7fbff]"
                  >
                    <RotateCcw className="h-4 w-4" /> Start fresh
                  </button>
                ) : null}
                {connectionState === "connected" ? (
                  <button
                    type="button"
                    onClick={stopConversation}
                    className="inline-flex items-center justify-center gap-2 rounded-full bg-[#103976] px-5 py-3 text-sm font-semibold text-white shadow-[0_14px_34px_rgba(15,59,130,0.18)] transition hover:brightness-110"
                  >
                    <PhoneOff className="h-4 w-4" /> End conversation
                  </button>
                ) : null}
              </div>

              {error ? <p className="mt-4 max-w-2xl text-sm text-[#b42318]">{error}</p> : null}
            </div>
          </div>

          <aside className="bg-[#fbfdff] px-5 py-8 sm:px-8 lg:px-7 lg:py-10">
            <div className="rounded-[30px] border border-[#dce7f5] bg-white p-6 shadow-[0_18px_50px_rgba(15,59,130,0.06)]">
              <p className="text-sm font-semibold uppercase tracking-[0.24em] text-[#4f77c4]">George helps with</p>
              <div className="mt-5 grid gap-3">
                {[
                  "Tickets, opening times and planning your visit",
                  "Directions around the park and what to do next",
                  "Animals, attractions and family-friendly facts",
                  "Food, drink, events and short stays",
                ].map((item) => (
                  <div key={item} className="rounded-2xl border border-[#e6eef9] bg-[#f8fbff] px-4 py-3 text-sm leading-6 text-[#33527f]">
                    {item}
                  </div>
                ))}
              </div>
            </div>

            <details className="mt-5 overflow-hidden rounded-[30px] border border-[#dce7f5] bg-white shadow-[0_18px_50px_rgba(15,59,130,0.06)]">
              <summary className="flex cursor-pointer list-none items-center justify-between px-6 py-5 text-left text-base font-semibold text-[#163867]">
                <span>View conversation</span>
                <ChevronDown className="h-5 w-5 text-[#4f77c4]" />
              </summary>
              <div ref={scrollRef} className="max-h-[420px] overflow-y-auto border-t border-[#edf3fb] px-4 py-4 sm:px-6">
                <div className="flex flex-col gap-4">
                  {visibleMessages.map((message) => (
                    <div key={message.id} className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}>
                      <div
                        className={`max-w-[92%] whitespace-pre-wrap rounded-[22px] px-4 py-3 text-sm leading-6 shadow-sm sm:max-w-[86%] ${
                          message.role === "user"
                            ? "rounded-br-md bg-[#123d82] text-white"
                            : "rounded-bl-md border border-[#e4edf8] bg-[#f7fbff] text-[#183868]"
                        }`}
                      >
                        {message.content}
                      </div>
                    </div>
                  ))}

                  {connectionState === "connecting" ? (
                    <div className="flex justify-start">
                      <div className="inline-flex items-center gap-3 rounded-[22px] rounded-bl-md border border-[#e4edf8] bg-[#f7fbff] px-4 py-3 text-sm text-[#33527f] shadow-sm">
                        <Loader2 className="h-4 w-4 animate-spin" /> George is joining the conversation…
                      </div>
                    </div>
                  ) : null}
                </div>
              </div>
            </details>
          </aside>
        </div>

        <div className="border-t border-[#e4edf8] bg-white px-5 py-7 sm:px-8 sm:py-8">
          <h2 className="text-2xl font-bold tracking-tight text-[#0f2f63]">Helpful buttons</h2>
          <div className="mt-5 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
            {QUICK_LINKS.map((link) => {
              const Icon = link.icon
              return (
                <a
                  key={link.label}
                  href={link.href}
                  className="group flex items-center justify-between gap-3 rounded-[22px] border border-[#d8e4f4] bg-[linear-gradient(145deg,#0d2d61_0%,#15448f_60%,#3e6fc6_100%)] px-4 py-4 text-sm font-semibold text-white shadow-[0_14px_34px_rgba(15,59,130,0.15)] transition hover:-translate-y-0.5 hover:brightness-110"
                >
                  <span>{link.label}</span>
                  <span className="flex h-9 w-9 items-center justify-center rounded-full bg-white/14">
                    <Icon className="h-4 w-4" />
                  </span>
                </a>
              )
            })}
          </div>
        </div>
      </div>
    </section>
  )
}
